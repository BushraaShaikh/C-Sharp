using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a string in uppercase:");
        string input = Console.ReadLine();

        string lowerCaseString = ConvertToLowercase(input);

        Console.WriteLine("Lowercase version: " + lowerCaseString);
    }

    static string ConvertToLowercase(string str)
    {
        return str.ToLower();
    }
}
