using System;
using System.Net;

class Program
{
    static void Main()
    {
        string hostName = Dns.GetHostName();
        Console.WriteLine("Host Name: " + hostName);

        IPHostEntry hostEntry = Dns.GetHostEntry(hostName);

        foreach (IPAddress ipAddress in hostEntry.AddressList)
        {
            Console.WriteLine("IP Address: " + ipAddress.ToString());
        }
    }
}
