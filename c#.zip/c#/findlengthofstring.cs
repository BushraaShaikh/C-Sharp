using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();

        int length = GetStringLength(input);

        Console.WriteLine("Length of the string: " + length);
    }

    static int GetStringLength(string str)
    {
        return str.Length;
    }
}
