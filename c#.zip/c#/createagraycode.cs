using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the number of bits for Gray code:");
        int n = int.Parse(Console.ReadLine());

        List<string> grayCodes = GenerateGrayCode(n);

        Console.WriteLine("Gray code sequence for " + n + " bits:");
        foreach (string code in grayCodes)
        {
            Console.WriteLine(code);
        }
    }

    static List<string> GenerateGrayCode(int n)
    {
        // Base case
        if (n == 0)
        {
            return new List<string> { "0" };
        }
        else if (n == 1)
        {
            return new List<string> { "0", "1" };
        }

        // Recursive case
        List<string> previousGrayCode = GenerateGrayCode(n - 1);
        List<string> grayCode = new List<string>();

        // Append '0' to the previous Gray code sequence
        foreach (string code in previousGrayCode)
        {
            grayCode.Add("0" + code);
        }

        // Append '1' to the reverse of the previous Gray code sequence
        for (int i = previousGrayCode.Count - 1; i >= 0; i--)
        {
            grayCode.Add("1" + previousGrayCode[i]);
        }

        return grayCode;
    }
}
