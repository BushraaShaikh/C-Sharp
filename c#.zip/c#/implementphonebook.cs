using System;
using System.Collections.Generic;

class PhoneBook
{
    private Dictionary<string, string> contacts;

    public PhoneBook()
    {
        contacts = new Dictionary<string, string>();
    }

    public void AddContact(string name, string phoneNumber)
    {
        if (!contacts.ContainsKey(name))
        {
            contacts[name] = phoneNumber;
            Console.WriteLine("Contact '" + name + "' added successfully.");
        }
        else
        {
            Console.WriteLine("Contact '" + name + "' already exists.");
        }
    }

    public void RemoveContact(string name)
    {
        if (contacts.ContainsKey(name))
        {
            contacts.Remove(name);
            Console.WriteLine("Contact '" + name + "' removed successfully.");
        }
        else
        {
            Console.WriteLine("Contact '" + name + "' does not exist.");
        }
    }

    public void SearchContact(string name)
    {
        if (contacts.ContainsKey(name))
        {
            string phoneNumber = contacts[name];
            Console.WriteLine("Contact '" + name + "' found with phone number: " + phoneNumber);
        }
        else
        {
            Console.WriteLine("Contact '" + name + "' not found.");
        }
    }

    public void DisplayContacts()
    {
        Console.WriteLine("Phone Book Contacts:");
        foreach (var contact in contacts)
        {
            Console.WriteLine(contact.Key + ": " + contact.Value);
        }
    }
}

class Program
{
    static void Main()
    {
        PhoneBook phoneBook = new PhoneBook();

        // Adding contacts
        phoneBook.AddContact("John Doe", "123-456-7890");
        phoneBook.AddContact("Jane Smith", "987-654-3210");

        // Display all contacts
        phoneBook.DisplayContacts();

        // Searching for a contact
        phoneBook.SearchContact("John Doe");

        // Removing a contact
        phoneBook.RemoveContact("Jane Smith");

        // Display updated contacts
        phoneBook.DisplayContacts();
    }
}
