using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter temperature in Celsius:");
        double celsius = double.Parse(Console.ReadLine());

        double fahrenheit = ConvertCelsiusToFahrenheit(celsius);

        Console.WriteLine("Temperature in Fahrenheit: " + fahrenheit.ToString("F2"));
    }

    static double ConvertCelsiusToFahrenheit(double celsius)
    {
        // Formula to convert Celsius to Fahrenheit
        double fahrenheit = (celsius * 9 / 5) + 32;
        return fahrenheit;
    }
}
