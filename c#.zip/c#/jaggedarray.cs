using System;

class Program
{
    static void Main()
    {
        // Declare and initialize a jagged array
        int[][] jaggedArray = new int[3][];

        // Initialize each row (sub-array)
        jaggedArray[0] = new int[] { 1, 2, 3 };
        jaggedArray[1] = new int[] { 4, 5 };
        jaggedArray[2] = new int[] { 6, 7, 8, 9 };

        // Display the elements of the jagged array
        Console.WriteLine("Jagged Array Elements:");

        // Iterate over each row (sub-array)
        for (int i = 0; i < jaggedArray.Length; i++)
        {
            // Iterate over each element in the current row
            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                Console.Write(jaggedArray[i][j] + " ");
            }
            Console.WriteLine(); // Move to the next line for the next row
        }
    }
}
