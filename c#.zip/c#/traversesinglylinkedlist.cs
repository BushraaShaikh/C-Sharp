using System;

// Node class representing a node in the linked list
public class Node
{
    public int data; // Data stored in the node
    public Node next; // Reference to the next node in the list

    // Constructor to initialize a new node with given data
    public Node(int data)
    {
        this.data = data;
        this.next = null;
    }
}

// Linked list class representing the singly linked list
public class SinglyLinkedList
{
    public Node head; // Head node of the list

    // Constructor to initialize an empty list
    public SinglyLinkedList()
    {
        this.head = null;
    }

    // Method to insert a new node at the end of the list
    public void Insert(int data)
    {
        Node newNode = new Node(data);

        if (head == null)
        {
            head = newNode;
        }
        else
        {
            Node current = head;
            while (current.next != null)
            {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to traverse and print all nodes in the list
    public void Traverse()
    {
        Node current = head;
        Console.Write("Linked List: ");
        while (current != null)
        {
            Console.Write(current.data + " ");
            current = current.next;
        }
        Console.WriteLine();
    }
}

class Program
{
    static void Main()
    {
        // Create a new singly linked list
        SinglyLinkedList myList = new SinglyLinkedList();

        // Insert nodes into the list
        myList.Insert(1);
        myList.Insert(2);
        myList.Insert(3);
        myList.Insert(4);
        myList.Insert(5);

        // Traverse and print the list
        myList.Traverse();
    }
}
