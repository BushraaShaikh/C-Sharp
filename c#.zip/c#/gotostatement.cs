using System;

class Program
{
    static void Main()
    {
        int counter = 0;

        Console.WriteLine("Start of the program.");

    startLoop:

        Console.WriteLine("Counter: " + counter);

        if (counter < 5)
        {
            counter++;
            goto startLoop;
        }

        Console.WriteLine("End of the program.");
    }
}
