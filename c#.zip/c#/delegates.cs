using System;

// Step 1: Declare a delegate type
delegate void MyDelegate(string message);

// Step 2: Create classes with methods that match the delegate signature
class Publisher
{
    // Method that matches the delegate signature
    public void PublishMessage(string message)
    {
        Console.WriteLine("Publisher is publishing: " + message);
    }
}

class Subscriber
{
    // Method that matches the delegate signature
    public void SubscribeToPublisher(string message)
    {
        Console.WriteLine("Subscriber received message: " + message);
    }
}

class Program
{
    static void Main()
    {
        // Step 3: Create instances of the delegate
        MyDelegate delegate1;

        // Step 4: Assign methods to the delegate instances
        Publisher publisher = new Publisher();
        Subscriber subscriber = new Subscriber();

        delegate1 = publisher.PublishMessage;
        delegate1 += subscriber.SubscribeToPublisher;

        // Step 5: Invoke the delegate (which invokes all methods it points to)
        delegate1("Hello, delegates!");

        // Step 6: Remove a method from the delegate
        delegate1 -= subscriber.SubscribeToPublisher;
        delegate1("Removing subscriber method");

        // Step 7: Check if delegate is null before invoking
        if (delegate1 != null)
        {
            delegate1("Invoking delegate again");
        }
    }
}
