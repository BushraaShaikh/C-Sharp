using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Choose what you want to calculate:");
        Console.WriteLine("1. Distance");
        Console.WriteLine("2. Speed");
        Console.WriteLine("3. Time");
        Console.WriteLine("Enter your choice (1/2/3):");

        int choice;
        while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 3)
        {
            Console.WriteLine("Invalid input. Please enter 1, 2, or 3:");
        }

        switch (choice)
        {
            case 1:
                CalculateDistance();
                break;
            case 2:
                CalculateSpeed();
                break;
            case 3:
                CalculateTime();
                break;
            default:
                Console.WriteLine("Invalid choice.");
                break;
        }
    }

    static void CalculateDistance()
    {
        Console.WriteLine("Enter speed (in km/h):");
        double speed = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter time (in hours):");
        double time = Convert.ToDouble(Console.ReadLine());

        double distance = speed * time;

        Console.WriteLine("Distance = " + distance + " kilometers");
    }

    static void CalculateSpeed()
    {
        Console.WriteLine("Enter distance (in kilometers):");
        double distance = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter time (in hours):");
        double time = Convert.ToDouble(Console.ReadLine());

        double speed = distance / time;

        Console.WriteLine("Speed = " + speed + " km/h");
    }

    static void CalculateTime()
    {
        Console.WriteLine("Enter distance (in kilometers):");
        double distance = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter speed (in km/h):");
        double speed = Convert.ToDouble(Console.ReadLine());

        double time = distance / speed;

        Console.WriteLine("Time = " + time + " hours");
    }
}
