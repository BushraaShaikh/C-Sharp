using System;
using System.Diagnostics;
using System.Threading;

class StopwatchProgram
{
    static void Main()
    {
        Stopwatch stopwatch = new Stopwatch();
        bool running = false;
        string command = "";

        Console.WriteLine("Simple Stopwatch Program");
        Console.WriteLine("Commands: start, stop, reset, exit");

        while (command != "exit")
        {
            Console.Write("Enter command: ");
            command = Console.ReadLine().ToLower();

            switch (command)
            {
                case "start":
                    if (!running)
                    {
                        stopwatch.Start();
                        running = true;
                        Console.WriteLine("Stopwatch started.");
                    }
                    else
                    {
                        Console.WriteLine("Stopwatch is already running.");
                    }
                    break;

                case "stop":
                    if (running)
                    {
                        stopwatch.Stop();
                        running = false;
                        Console.WriteLine("Stopwatch stopped.");
                    }
                    else
                    {
                        Console.WriteLine("Stopwatch is not running.");
                    }
                    break;

                case "reset":
                    stopwatch.Reset();
                    running = false;
                    Console.WriteLine("Stopwatch reset.");
                    break;

                case "exit":
                    Console.WriteLine("Exiting program.");
                    break;

                default:
                    Console.WriteLine("Invalid command. Please enter start, stop, reset, or exit.");
                    break;
            }

            Console.WriteLine("Elapsed time: {0}", stopwatch.Elapsed);
        }
    }
}
