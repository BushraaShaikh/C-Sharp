using System;

class Program
{
    static string[] ones = { "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
    static string[] teens = { "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", 
                              "seventeen", "eighteen", "nineteen" };
    static string[] tens = { "", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", 
                             "ninety" };

    static void Main()
    {
        Console.WriteLine("Enter a number (0 to 999):");
        int number = Convert.ToInt32(Console.ReadLine());

        if (number < 0 || number > 999)
        {
            Console.WriteLine("Number out of range (0 to 999).");
        }
        else if (number == 0)
        {
            Console.WriteLine("Zero");
        }
        else
        {
            string words = ConvertNumberToWords(number);
            Console.WriteLine("Number in words: " + words);
        }
    }

    static string ConvertNumberToWords(int number)
    {
        if (number < 10)
        {
            return ones[number];
        }
        else if (number < 20)
        {
            return teens[number - 10];
        }
        else if (number < 100)
        {
            return tens[number / 10] + " " + ones[number % 10];
        }
        else // number is 100 to 999
        {
            return ones[number / 100] + " hundred " + ConvertNumberToWords(number % 100);
        }
    }
}
