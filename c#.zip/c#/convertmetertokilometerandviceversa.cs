using System;

class ConversionProgram
{
    static void Main()
    {
        Console.WriteLine("Conversion Program");
        Console.WriteLine("1. Convert Meters to Kilometers");
        Console.WriteLine("2. Convert Kilometers to Meters");
        Console.WriteLine("Enter your choice (1 or 2): ");
        
        int choice;
        while (!int.TryParse(Console.ReadLine(), out choice) || (choice != 1 && choice != 2))
        {
            Console.WriteLine("Invalid input. Please enter 1 or 2: ");
        }

        double value, result;

        switch (choice)
        {
            case 1:
                Console.WriteLine("Enter value in meters: ");
                while (!double.TryParse(Console.ReadLine(), out value) || value < 0)
                {
                    Console.WriteLine("Invalid input. Please enter a non-negative number: ");
                }
                result = MetersToKilometers(value);
                Console.WriteLine(value + " meters is equal to " + result + " kilometers.");
                break;

            case 2:
                Console.WriteLine("Enter value in kilometers: ");
                while (!double.TryParse(Console.ReadLine(), out value) || value < 0)
                {
                    Console.WriteLine("Invalid input. Please enter a non-negative number: ");
                }
                result = KilometersToMeters(value);
                Console.WriteLine(value + " kilometers is equal to " + result + " meters.");
                break;
        }
    }

    static double MetersToKilometers(double meters)
    {
        return meters / 1000;
    }

    static double KilometersToMeters(double kilometers)
    {
        return kilometers * 1000;
    }
}
