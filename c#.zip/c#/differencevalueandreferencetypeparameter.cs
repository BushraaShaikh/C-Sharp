using System;

class Program
{
    static void Main()
    {
        // Value type parameter example
        int valueType = 5;
        Console.WriteLine("Before calling ModifyValueType: " + valueType);
        ModifyValueType(valueType);
        Console.WriteLine("After calling ModifyValueType: " + valueType);

        // Reference type parameter example
        int[] referenceType = { 1, 2, 3 };
        Console.WriteLine("Before calling ModifyReferenceType: " + string.Join(", ", referenceType));
        ModifyReferenceType(referenceType);
        Console.WriteLine("After calling ModifyReferenceType: " + string.Join(", ", referenceType));
    }

    // Method to modify a value type parameter
    static void ModifyValueType(int num)
    {
        num = 10;
        Console.WriteLine("Inside ModifyValueType: " + num);
    }

    // Method to modify a reference type parameter
    static void ModifyReferenceType(int[] array)
    {
        array[0] = 10;
        Console.WriteLine("Inside ModifyReferenceType: " + string.Join(", ", array));
    }
}
