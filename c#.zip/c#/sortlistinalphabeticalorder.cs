using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Create a list of names
        List<string> names = new List<string> { "John", "Alice", "Bob", "Eve", "Charlie" };

        // Sort the list alphabetically
        names.Sort();

        // Display the sorted list
        Console.WriteLine("Sorted Names:");
        foreach (string name in names)
        {
            Console.WriteLine(name);
        }
    }
}
