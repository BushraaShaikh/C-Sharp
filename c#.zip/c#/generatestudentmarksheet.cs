using System;
using System.Collections.Generic;

class MarksheetProgram
{
    static void Main()
    {
        string studentName;
        int rollNumber;
        int numberOfSubjects;
        Dictionary<string, int> subjects = new Dictionary<string, int>();

        // Collect student details
        Console.WriteLine("Enter Student Name: ");
        studentName = Console.ReadLine();

        Console.WriteLine("Enter Roll Number: ");
        while (!int.TryParse(Console.ReadLine(), out rollNumber))
        {
            Console.WriteLine("Invalid input. Please enter a valid roll number: ");
        }

        Console.WriteLine("Enter Number of Subjects: ");
        while (!int.TryParse(Console.ReadLine(), out numberOfSubjects) || numberOfSubjects <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a valid number of subjects: ");
        }

        // Collect marks for each subject
        for (int i = 0; i < numberOfSubjects; i++)
        {
            Console.WriteLine("Enter Subject Name: ");
            string subjectName = Console.ReadLine();

            int marks;
            Console.WriteLine("Enter Marks for " + subjectName + ": ");
            while (!int.TryParse(Console.ReadLine(), out marks) || marks < 0 || marks > 100)
            {
                Console.WriteLine("Invalid input. Please enter valid marks (0-100) for " + subjectName + ": ");
            }

            subjects[subjectName] = marks;
        }

        // Calculate total and average marks
        int totalMarks = 0;
        foreach (var subject in subjects)
        {
            totalMarks += subject.Value;
        }
        double averageMarks = (double)totalMarks / numberOfSubjects;

        // Display the marksheet
        Console.WriteLine("\nMarksheet");
        Console.WriteLine("---------");
        Console.WriteLine("Student Name: " + studentName);
        Console.WriteLine("Roll Number: " + rollNumber);
        Console.WriteLine("Subjects and Marks:");
        foreach (var subject in subjects)
        {
            Console.WriteLine(subject.Key + ": " + subject.Value);
        }
        Console.WriteLine("Total Marks: " + totalMarks);
        Console.WriteLine("Average Marks: " + averageMarks);

        // Determine the grade
        string grade;
        if (averageMarks >= 90)
        {
            grade = "A+";
        }
        else if (averageMarks >= 80)
        {
            grade = "A";
        }
        else if (averageMarks >= 70)
        {
            grade = "B";
        }
        else if (averageMarks >= 60)
        {
            grade = "C";
        }
        else if (averageMarks >= 50)
        {
            grade = "D";
        }
        else
        {
            grade = "F";
        }
        Console.WriteLine("Grade: " + grade);
    }
}
