using System;
using System.Collections.Generic;
using System.Text;

class InfixToPostfixConverter
{
    static void Main()
    {
        Console.WriteLine("Enter an infix expression (e.g., 3 + 4 * 2 / (1 - 5)^2): ");
        string infixExpression = Console.ReadLine().Trim();

        string postfixExpression = ConvertToPostfix(infixExpression);

        Console.WriteLine("Postfix expression: " + postfixExpression);
    }

    static string ConvertToPostfix(string infix)
    {
        StringBuilder postfix = new StringBuilder();
        Stack<char> operators = new Stack<char>();

        Dictionary<char, int> precedence = new Dictionary<char, int>
        {
            {'+', 1}, {'-', 1},
            {'*', 2}, {'/', 2},
            {'^', 3}
        };

        foreach (char c in infix)
        {
            if (char.IsDigit(c))
            {
                postfix.Append(c);
            }
            else if (c == '(')
            {
                operators.Push(c);
            }
            else if (c == ')')
            {
                while (operators.Count > 0 && operators.Peek() != '(')
                {
                    postfix.Append(operators.Pop());
                }
                operators.Pop(); // Pop '('
            }
            else
            {
                while (operators.Count > 0 && precedence[operators.Peek()] >= precedence[c])
                {
                    postfix.Append(operators.Pop());
                }
                operators.Push(c);
            }
        }

        while (operators.Count > 0)
        {
            postfix.Append(operators.Pop());
        }

        return postfix.ToString();
    }
}
