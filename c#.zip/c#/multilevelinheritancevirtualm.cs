using System;

// Base class
class Animal
{
    // Virtual method
    public virtual void Eat()
    {
        Console.WriteLine("Animal is eating.");
    }
}

// Derived class inheriting from Animal
class Dog : Animal
{
    // Override method
    public override void Eat()
    {
        Console.WriteLine("Dog is eating dog food.");
    }
}

// Further derived class inheriting from Dog
class Labrador : Dog
{
    // Override method
    public override void Eat()
    {
        Console.WriteLine("Labrador is eating Labrador food.");
    }
}

class Program
{
    static void Main()
    {
        // Creating instances of each class
        Animal animal = new Animal();
        Dog dog = new Dog();
        Labrador labrador = new Labrador();

        // Calling Eat method for each instance
        Console.WriteLine("Calling Eat method for each instance:");
        animal.Eat();       // Output: Animal is eating.
        dog.Eat();          // Output: Dog is eating dog food.
        labrador.Eat();     // Output: Labrador is eating Labrador food.

        // Demonstrating polymorphism
        Animal animalDog = new Dog();           // Dog instance as Animal reference
        Animal animalLabrador = new Labrador(); // Labrador instance as Animal reference

        // Calling Eat method for polymorphic instances
        Console.WriteLine("\nCalling Eat method for polymorphic instances:");
        animalDog.Eat();       // Output: Dog is eating dog food.
        animalLabrador.Eat();  // Output: Labrador is eating Labrador food.
    }
}
