using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        string phonePattern = @"^\d{3}-\d{3}-\d{4}$";
        string digitsPattern = @"^\d+$";

        Console.WriteLine("Enter an email address:");
        string emailInput = Console.ReadLine();
        ValidatePattern(emailInput, emailPattern, "Email");

        Console.WriteLine("Enter a phone number (format: 123-456-7890):");
        string phoneInput = Console.ReadLine();
        ValidatePattern(phoneInput, phonePattern, "Phone Number");

        Console.WriteLine("Enter a sequence of digits:");
        string digitsInput = Console.ReadLine();
        ValidatePattern(digitsInput, digitsPattern, "Digits");
    }

    static void ValidatePattern(string input, string pattern, string patternName)
    {
        if (Regex.IsMatch(input, pattern))
        {
            Console.WriteLine(patternName + " is valid.");
        }
        else
        {
            Console.WriteLine(patternName + " is not valid.");
        }
    }
}
