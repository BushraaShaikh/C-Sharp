using System;

namespace MyApplication
{
    // Define a namespace for utility functions
    namespace Utilities
    {
        public class MathUtils
        {
            public static int Add(int a, int b)
            {
                return a + b;
            }

            public static int Subtract(int a, int b)
            {
                return a - b;
            }
        }

        public class StringUtils
        {
            public static string Concatenate(string a, string b)
            {
                return a + b;
            }

            public static int GetLength(string str)
            {
                return str.Length;
            }
        }
    }

    // Main program
    class Program
    {
        static void Main()
        {
            // Using the MathUtils class from the Utilities namespace
            int sum = Utilities.MathUtils.Add(5, 3);
            int difference = Utilities.MathUtils.Subtract(5, 3);

            Console.WriteLine("Sum: {sum}");
            Console.WriteLine("Difference: {difference}");

            // Using the StringUtils class from the Utilities namespace
            string combined = Utilities.StringUtils.Concatenate("Hello, ", "World!");
            int length = Utilities.StringUtils.GetLength("Hello");

            Console.WriteLine("Combined String: {combined}");
            Console.WriteLine("Length of 'Hello': {length}");
        }
    }
}
