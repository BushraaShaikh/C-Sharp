using System;

class Program
{
    static void Main()
    {
        // Get the local time zone
        TimeZoneInfo localZone = TimeZoneInfo.Local;

        Console.WriteLine("Local Time Zone: " + localZone.DisplayName);
        Console.WriteLine("Standard Time Name: " + localZone.StandardName);
        Console.WriteLine("Daylight Saving Time Name: " + localZone.DaylightName);

        // Check if the time zone supports daylight saving time
        bool supportsDst = localZone.SupportsDaylightSavingTime;
        Console.WriteLine("Supports Daylight Saving Time: " + supportsDst);

        if (supportsDst)
        {
            // Get the daylight saving time changes for the current year
            DateTime start = DateTime.Now;
            TimeSpan delta = new TimeSpan(365, 0, 0, 0); // 1 year
            TimeZoneInfo.AdjustmentRule[] rules = localZone.GetAdjustmentRules();

            foreach (var rule in rules)
            {
                if (rule.DateStart <= start && rule.DateEnd >= start)
                {
                    Console.WriteLine("Daylight Saving Time starts: " + rule.DaylightTransitionStart);
                    Console.WriteLine("Daylight Saving Time ends: " + rule.DaylightTransitionEnd);
                    break;
                }
            }
        }
        else
        {
            Console.WriteLine("This time zone does not observe Daylight Saving Time.");
        }
    }
}

