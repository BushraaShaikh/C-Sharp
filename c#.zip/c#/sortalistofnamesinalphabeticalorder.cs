using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Initialize the list of names
        List<string> names = new List<string>
        {
            "John",
            "Alice",
            "Bob",
            "Diana",
            "Charlie"
        };

        // Display the original list
        Console.WriteLine("Original list:");
        foreach (string name in names)
        {
            Console.WriteLine(name);
        }

        // Sort the list in alphabetical order
        names.Sort();

        // Display the sorted list
        Console.WriteLine("\nSorted list:");
        foreach (string name in names)
        {
            Console.WriteLine(name);
        }
    }
}
