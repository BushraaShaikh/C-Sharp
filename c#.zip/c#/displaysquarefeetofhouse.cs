using System;

class SquareFeetCalculator
{
    static void Main()
    {
        double length, width, area;

        // Collect the length of the house
        Console.WriteLine("Enter the length of the house in feet: ");
        while (!double.TryParse(Console.ReadLine(), out length) || length <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a positive number for the length: ");
        }

        // Collect the width of the house
        Console.WriteLine("Enter the width of the house in feet: ");
        while (!double.TryParse(Console.ReadLine(), out width) || width <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a positive number for the width: ");
        }

        // Calculate the area
        area = CalculateSquareFeet(length, width);

        // Display the result
        Console.WriteLine("The square footage of the house is: " + area + " square feet.");
    }

    static double CalculateSquareFeet(double length, double width)
    {
        return length * width;
    }
}
