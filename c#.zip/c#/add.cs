using System;
namespace addition
{
    class Addition{
        static void Main(string[] args){
            int a=45,b=45;
            int c=a+b;
            Console.WriteLine("Addition : "+c);
        }
    }
}
