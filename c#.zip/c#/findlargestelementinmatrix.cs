using System;

class Program
{
    static void Main()
    {
        // Example 2D matrix
        int[,] matrix = {
            { 5, 8, 12 },
            { 3, 9, 4 },
            { 15, 2, 7 }
        };

        // Get dimensions of the matrix
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        // Initialize maxElement with the first element of the matrix
        int maxElement = matrix[0, 0];

        // Traverse the matrix to find the largest element
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (matrix[i, j] > maxElement)
                {
                    maxElement = matrix[i, j];
                }
            }
        }

        // Print the largest element found
        Console.WriteLine("The largest element in the matrix is: " + maxElement);
    }
}
