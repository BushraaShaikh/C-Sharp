using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Calculate Simple Interest:");
        
        // Input principal amount
        Console.Write("Enter principal amount (P): ");
        double principal = Convert.ToDouble(Console.ReadLine());

        // Input rate of interest
        Console.Write("Enter annual interest rate (R) in percentage: ");
        double rate = Convert.ToDouble(Console.ReadLine());

        // Input time period in years
        Console.Write("Enter time period (T) in years: ");
        double time = Convert.ToDouble(Console.ReadLine());

        // Calculate simple interest
        double simpleInterest = (principal * rate * time) / 100;

        // Output the result
        Console.WriteLine("Simple Interest = " + simpleInterest);

        // Optionally, you can display the total amount after interest
        double totalAmount = principal + simpleInterest;
        Console.WriteLine("Total amount after interest = " + totalAmount);
    }
}
